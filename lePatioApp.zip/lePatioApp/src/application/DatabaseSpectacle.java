package application;

import java.time.LocalDate;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DatabaseSpectacle {
	
	private ObservableList<Spectacle> listeSpectacles;
	private ObservableList<String> listeNomSpectacles;
	private ObservableList<Fauteuil> listeFauteuils;
	
	
	public DatabaseSpectacle() {
		Representation repre = new Representation(LocalDate.of(2024,06, 21), "String heure", false, null);
        Zone zoneH = new Zone("h",null);
        Spectacle spec1 = new Spectacle("Oui oui : La rue la vraie", 1, 1, "String genre", repre, zoneH, new Artiste("Samuel"));
        Spectacle spec2 = new Spectacle("Ziak : Chrome Tour", 1, 1, "String genre", repre, zoneH, new Artiste("Ziak"));
        Spectacle spec3 = new Spectacle("Evan Beats : LEGEND EDITION", 1, 1, "String genre", repre, zoneH, new Artiste("Evan Beats"));
        Spectacle spec4 = new Spectacle("Guignol : La vérité sur les cartels", 1, 1, "String genre", repre, zoneH, new Artiste("Pablo Escobar"));
        Spectacle spec5 = new Spectacle("SAE BDD : Le sketch de ma vie", 1, 1, "String genre", repre, zoneH, new Artiste("HES"));
        Zone fosse = new Zone("Fosse", spec2);
        Zone gradins = new Zone("Gradins", spec1);
        Zone gradinsHauteurs = new Zone("Places Hauteur", spec3);
        
        Fauteuil fg_1A= new Fauteuil("1","A",gradins);
        Fauteuil fg_2A= new Fauteuil("2","A",gradins);
        Fauteuil fg_3A= new Fauteuil("3","A",gradins);
        Fauteuil fg_1B= new Fauteuil("1","B",gradins);
        Fauteuil fg_2B= new Fauteuil("2","B",gradins);
        
        Fauteuil fgh_1A= new Fauteuil("1","A",gradinsHauteurs);
        Fauteuil fgh_2A= new Fauteuil("2","A",gradinsHauteurs);
        Fauteuil fgh_3A= new Fauteuil("3","A",gradinsHauteurs);
        Fauteuil fgh_1B= new Fauteuil("1","B",gradinsHauteurs);
        Fauteuil fgh_2B= new Fauteuil("2","B",gradinsHauteurs);

        spec1.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 20), "22:00", false, spec1));
        spec2.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 20), "12:00", false, spec2));
        spec2.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 20), "16:00", false, spec2));
        spec3.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 21), "16:00", false, spec3));
        spec4.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 24), "15:00", false, spec4));
        spec5.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 22), "15:00", false, spec5));
        spec5.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 22), "22:00", false, spec5));
        spec5.ajouterRepresentation(new Representation(LocalDate.of(2024,06, 25), "19:00", false, spec5));
        spec1.supprimerRepresentation(repre);
        spec2.supprimerRepresentation(repre);
        spec3.supprimerRepresentation(repre);
        spec4.supprimerRepresentation(repre);
        spec5.supprimerRepresentation(repre);
        spec1.ajouterZone(gradins);
        spec1.ajouterZone(gradinsHauteurs);
        spec2.ajouterZone(gradins);
        spec2.ajouterZone(fosse);
        spec3.ajouterZone(fosse);
        spec3.ajouterZone(gradinsHauteurs);
        spec4.ajouterZone(gradinsHauteurs);
        spec4.ajouterZone(gradins);
        spec5.ajouterZone(gradinsHauteurs);
        spec5.ajouterZone(gradins);
        spec5.ajouterZone(fosse);
        spec1.supprimerZone(zoneH);
        spec2.supprimerZone(zoneH);
        spec3.supprimerZone(zoneH);
        spec4.supprimerZone(zoneH);
        spec5.supprimerZone(zoneH);

        
		listeSpectacles = FXCollections.observableArrayList();
		listeNomSpectacles = FXCollections.observableArrayList();
		listeSpectacles.add(spec1);
		listeNomSpectacles.add(spec1.nom);
		listeSpectacles.add(spec2);
		listeNomSpectacles.add(spec2.nom);
		listeSpectacles.add(spec3);
		listeNomSpectacles.add(spec3.nom);
		listeSpectacles.add(spec4);
		listeNomSpectacles.add(spec4.nom);
		listeSpectacles.add(spec5);
		listeNomSpectacles.add(spec5.nom);
		
		listeFauteuils = FXCollections.observableArrayList();
		listeFauteuils.add(fg_1A);
		listeFauteuils.add(fg_2A);
		listeFauteuils.add(fg_3A);
		listeFauteuils.add(fg_1B);
		listeFauteuils.add(fg_2B);
		
		listeFauteuils.add(fgh_1A);
		listeFauteuils.add(fgh_2A);
		listeFauteuils.add(fgh_3A);
		listeFauteuils.add(fgh_1B);
		listeFauteuils.add(fgh_2B);
	}
	
	public ObservableList<Spectacle> getSpectacles(){
		return listeSpectacles;
	}
	
	public ObservableList<Fauteuil> getFauteuils(){
		return listeFauteuils;
	}
	
	public ObservableList<String> getNomSpectacles(){
		return listeNomSpectacles;
	}
	
	public void add(Spectacle spectacle) {
		listeSpectacles.add(spectacle);
	}
}
