package application;

import javafx.application.Application;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Main extends Application {
	static private FenAccueil 	fAccueil;
	static private FenReservation 	fReservation;
	static private FenClient 	fClient;

	@Override
	public void start(Stage primaryStage) throws Exception {
		fAccueil = new FenAccueil();
		fAccueil.initModality(Modality.APPLICATION_MODAL);
		fAccueil.setTitle("Application LePatio");
		fAccueil.setResizable(false);
		
		fReservation = new FenReservation();
		fReservation.initModality(Modality.APPLICATION_MODAL);
		fReservation.setTitle("Créer réservation");
		fReservation.setResizable(false);
		
		fClient = new FenClient();
		fClient.initModality(Modality.APPLICATION_MODAL);
		fClient.setTitle("Créer client");
		fClient.setResizable(false);

		fAccueil.show();
	}
	
	public static void ouvrirFenClient() throws Exception {
		fClient.show();
	}
	
	public static void ouvrirFenReservation() throws Exception {
		fReservation.show();
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
	
	public static void fermerClient() {
		fClient.close();
	}
	
	public static void fermerReservation() {
		fReservation.close();
	}
}