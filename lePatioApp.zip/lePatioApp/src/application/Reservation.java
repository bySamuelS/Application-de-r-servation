package application;

import java.time.LocalDate;
import java.util.*;

public class Reservation {
    protected String numero;
    protected LocalDate date;
    protected LocalDate dateEnvoiConf;
    protected ArrayList<Billet> listBillet;
    protected Representation representation;
    protected Client client;

    public Reservation(String numero, LocalDate date, LocalDate dateEnvoiConf, Client client) {
        this.numero = numero;
        this.date = date;
        this.dateEnvoiConf = dateEnvoiConf;
        this.client = client;
    }

    public String getNumero() {
        return numero;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalDate getDateEnvoiConf() {
        return dateEnvoiConf;
    }

    public void setDateEnvoiConf(LocalDate dateEnvoiConf) {
        this.dateEnvoiConf = dateEnvoiConf;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    protected void addBillet(Billet billet) {
        listBillet.add(billet);
    }

    protected void removeBillet(Billet billet) {
        listBillet.remove(billet);
    }

    protected int nbBillet(ArrayList<Billet> listBillet) {
        return listBillet.size();
    }

    public void ajouterBillet(Billet billet) {
        if (billet.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (listBillet.contains(billet)) {
            System.out.println("Billet deja présent dans la liste !");
        }  else {
            addBillet(billet);
        }
    }

    public void supprimerBillet(Billet billet) {
        if (billet.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (!listBillet.contains(billet)) {
            System.out.println("Billet non présent dans la liste !");
        } else if (nbBillet(listBillet) == 1) {
            System.out.println("Impossible de supprimer le billet, il est le seul de la liste !");
        } else {
            removeBillet(billet);
        }
    }
    // equals
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Reservation other = (Reservation) obj;
        return Objects.equals(numero, other.numero);
    }

    // toString
    public String toString() {
        return "Reservation [numero=" + numero + ", date=" + date + ", dateEnvoiConf=" + dateEnvoiConf + ", listBillet="
                + listBillet + "]";
    }

    // affiche
    public void affiche() {
        System.out.println(this.toString());
    }

    public void setRepresentation(Representation representation) {
        this.representation = representation;
    }
    public Representation getRepresentation() {
        return this.representation;
    }

    // modifier representation
    private void editRepresentation(Representation representation) {
        this.representation = representation;
    }

    public void modifierRepresentation(Representation representation) {
        if (representation.equals(null)) {
            System.out.println("Entrée nulle !");
        } else {
            editRepresentation(representation);
        }
    }

    // modifier client
    private void editClient(Client client) {
        this.client = client;
    }

    public void modifierClient(Client client) {
        if (client.equals(null)) {
            System.out.println("Entrée nulle !");
        } else {
            editClient(client);
        }
    }
};