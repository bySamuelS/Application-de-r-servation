package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DatabaseClient {
	
	private ObservableList<Client> listeClients;
	
	public DatabaseClient() {
		listeClients = FXCollections.observableArrayList();
		listeClients.add(new Client("Collet","Evan","Rue Edouard Branly, 22300 Lannion","0764093254","evancollet.22@gmail.com"));
	}
	
	public ObservableList<Client> getClients(){
		return listeClients;
	}
	
	// Méthode pour retrouver un client par son numéro de client
    public Client trouverClientParNumero(int numeroClient) {
        for (Client client : listeClients) {
            if (client.getNumero() == numeroClient) {
                return client;
            }
        }
        return null; // Retourne null si le client n'est pas trouvé
    }
	
	public void add(Client client) {
		listeClients.add(client);
	}
}
