package application;

public class Abonne extends Client {
    private boolean estAbonne = false;

    // Constructeur
    public Abonne(String nom, String prenom, String adresse, String tel, String mail, Boolean estAbonne) {
        super(nom, prenom, adresse, tel, mail);
        this.estAbonne = estAbonne;
    }

    // Méthodes
    public void devientAbonne() {
        if (this.estAbonne == true) {
            System.out.println("Le client " + this.nom + " " + this.prenom + " est déjà abonné.");
            return; 
        }
        else if ((this.estAbonne == false) && (troisReservations())) {
        System.out.println("Le client " + this.nom + " " + this.prenom + " est devenu abonné.");
        }
    }

    public boolean troisReservations() {
        if (super.reservations.size() >= 3) {
            for (int i = 0; i < reservations.size(); i++) {
                if ((super.reservations.get(i).getDate() == super.reservations.get(i+1).getDate()) 
                && (super.reservations.get(i).getDate() == super.reservations.get(i+2).getDate())) {
                    return true;
                }
            }
        }
        return false;
    }

}