package application;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Client {
    protected String nom;
    protected String prenom;
    protected String adresse;
    protected String tel;
    protected String mail;
    protected int numero;
    public boolean estAbonne;
    protected List<Reservation> reservations;
    int min = 1000000; // Minimum value
    int max = 9999999; // Maximum value

    

    public Client(String nom, String prenom, String adresse, String tel, String mail) {
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.tel = tel;
        this.mail = mail;
        Random rand = new Random();
        int randomNumber = rand.nextInt(max - min + 1) + min;
        this.numero = randomNumber;
        this.reservations = new ArrayList<Reservation>();
        this.estAbonne = false;
    }
    
    

    public String getNom() {
		return nom;
	}



	public String getPrenom() {
		return prenom;
	}



	public String getAdresse() {
		return adresse;
	}



	public String getTel() {
		return tel;
	}



	public String getMail() {
		return mail;
	}



	public int getNumero() {
        return numero;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    //ajouter reservation
    private void addReservation(Reservation reservation) {
        this.reservations.add(reservation);
    }

    public void ajouterReservation(Reservation reservation) {
    	if (reservations.contains(reservation)) {
            System.out.println("Réservation déjà présente dans la liste !");
        } else {
            addReservation(reservation);
        }
    }

    //supprimer reservation
    private void removeReservation(Reservation reservation) {
        this.reservations.remove(reservation);
    }

    public void supprimerReservation(Reservation reservation) {
        if (reservation.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (!reservations.contains(reservation)) {
            System.out.println("Réservation non présente dans la liste !");
        } else if (reservations.size() <= 1) {
            System.out.println("Il n'y a qu'une seule réservation !");
        } else {
            removeReservation(reservation);
        }
    }
    
    public boolean eligibleAbonnement() {
    	return reservations.size() >= 3;
    }
    
    public int nbResAFaireAuj() {
    	return 3 - reservations.size();
    }
}