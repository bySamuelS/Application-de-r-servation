package application;

import javafx.beans.binding.BooleanBinding;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.application.Application;


public class CtrlFenAccueil {
	
	public static DatabaseClient DBClient = new DatabaseClient();
	
	@FXML private Button bnFermer;
    @FXML private Button bnClient;
    @FXML private Button bnReservation;
    @FXML private Button bnAbo;
    @FXML private TableView<Client> tableV;
    @FXML private TableColumn<Client, String> colNom;
    @FXML private TableColumn<Client, String> colPrenom;
    @FXML private TableColumn<Client, String> colAdresse;
    @FXML private TableColumn<Client, String> colTel;
    @FXML private TableColumn<Client, String> colMail;
    @FXML private TableColumn<Client, String> colNum;

    @FXML void clicAnnuler(ActionEvent event) throws Exception {
    	System.exit(0);
    }

    @FXML void clicClient(ActionEvent event) throws Exception {    
    	Main.ouvrirFenClient();
    }
    
    @FXML void clicReservation(ActionEvent event) throws Exception {    
    	Main.ouvrirFenReservation();
    }
    
    private Client clientSelec;
    
    @FXML void clicAbo(ActionEvent event) throws Exception {   
    	if(clientSelec.eligibleAbonnement() && clientSelec.estAbonne == false) {
    		Alert alerte = new Alert(Alert.AlertType.CONFIRMATION);
    		
    		alerte.setTitle("Client éligible abonnement");
            alerte.setHeaderText("Mr/Mme "+clientSelec.nom+" est éligible à l'abonnement Le Patio !");
            alerte.setContentText("Voulez-vous abonner le client ?");
            
            ButtonType btnAbonnerClient = new ButtonType("Abonner client");
            ButtonType btnAnnuler = new ButtonType("Annuler");
            
            alerte.getButtonTypes().setAll(btnAbonnerClient, btnAnnuler);
            
            alerte.showAndWait().ifPresent(buttonType -> {
                if (buttonType == btnAbonnerClient) {
                	Alert alerte2 = new Alert(Alert.AlertType.INFORMATION);
                	
                	alerte2.setTitle("Abonnement effectué !");
                    alerte2.setHeaderText("Mr/Mme "+clientSelec.nom+" est désormais abonné !");
                    clientSelec.estAbonne = true;
                    
                    alerte2.showAndWait();
                } else {
                    System.out.println("Action annulée.");
                }
            });
    	}
    	else {
    		if(clientSelec.estAbonne == false) {
	    		Alert alerte = new Alert(Alert.AlertType.WARNING);
		        alerte.setTitle("Client non eligible");
		        alerte.setHeaderText("Mr/Mme "+clientSelec.nom+" n'est pas éligible à l'abonnement !");
		        alerte.setContentText("Encore "+clientSelec.nbResAFaireAuj()+" réservations à faire aujourd'hui");
		
		        ButtonType btnReserver = new ButtonType("Réserver");
		        ButtonType btnAnnuler = new ButtonType("Annuler");
		
		        alerte.getButtonTypes().setAll(btnReserver, btnAnnuler);
		
		        alerte.showAndWait().ifPresent(buttonType -> {
		            if (buttonType == btnReserver) {
		                // Ajoutez ici la logique pour créer un nouveau client
		                System.out.println("Création d'une nouvelle réservation...");
		                // Exemple : Ouverture d'une nouvelle fenêtre pour créer un client
		                try {
							Main.ouvrirFenReservation();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
		            } else {
		                System.out.println("Action annulée.");
		            }
		        });
    		}else {
    			Alert alerte2 = new Alert(Alert.AlertType.INFORMATION);
            	
            	alerte2.setTitle("Abonnement déjà en cours !");
                alerte2.setHeaderText("Mr/Mme "+clientSelec.nom+" est déjà abonné !");
                
                alerte2.showAndWait();
    		}}
    }
    
    
    @FXML void tablecliquee(MouseEvent event) {
    	clientSelec = tableV.getSelectionModel().getSelectedItem();	
    	bnAbo.setDisable(false);
    }
    
    public void initialize() {
    	colNom.setCellValueFactory(new PropertyValueFactory<Client, String>("nom"));
    	colPrenom.setCellValueFactory(new PropertyValueFactory<Client, String>("prenom"));
    	colAdresse.setCellValueFactory(new PropertyValueFactory<Client, String>("adresse"));
    	colTel.setCellValueFactory(new PropertyValueFactory<Client, String>("tel"));
    	colMail.setCellValueFactory(new PropertyValueFactory<Client, String>("mail"));
    	colNum.setCellValueFactory(new PropertyValueFactory<Client, String>("numero"));
    	tableV.setItems(DBClient.getClients());
    }
}