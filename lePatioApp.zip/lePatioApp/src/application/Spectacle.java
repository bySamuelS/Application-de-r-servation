package application;

import java.util.List;
import java.util.ArrayList;

public class Spectacle {
    protected String nom;
    private int duree;
    private int nombreActes;
    private String genre;
    public List<Representation> representations;
    public List<Zone> ListeZone;

    // Associations
    private List<Artiste> artistes;

    // Constructeur
    public Spectacle(String nom, int duree, int nombreActes, String genre, Representation representation, Zone zone, Artiste artiste) {
        this.nom = nom;
        this.duree = duree;
        this.nombreActes = nombreActes;
        this.genre = genre;
        this.representations = new ArrayList<Representation>();
        this.ListeZone = new ArrayList<Zone>();
        this.artistes = new ArrayList<Artiste>();
        this.addRepresentation(representation);
        this.addZone(zone);
        this.addArtiste(artiste);
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
    
    public String getNom() {
    	return nom;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public int getNombreActes() {
        return nombreActes;
    }

    public void setNombreActes(int nombreActes) {
        this.nombreActes = nombreActes;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public List<Artiste> getArtistes() {
        return artistes;
    }

    public void setArtistes(List<Artiste> artistes) {
        this.artistes = artistes;
    }

    public List<Representation> getRepresentations() {
        return representations;
    }

    protected void setRepresentations(List<Representation> representations) {
        this.representations = representations;
    }

    public List<Zone> getListeZone() {
        return ListeZone;
    }

    protected void setListeZone(List<Zone> listeZone) {
        this.ListeZone = listeZone;
    }

    protected void addArtiste(Artiste artiste) {
        this.artistes.add(artiste);
    }

    protected void removeArtiste(Artiste artiste) {
        this.artistes.remove(artiste);
    }

    // add Zone
    protected void addZone(Zone zone) {
        this.ListeZone.add(zone);
    }

    // remove Zone
    protected void removeZone(Zone zone) {
        this.ListeZone.remove(zone);
    }

    private int nbArtiste() {
        return artistes.size();
    }

    protected void addSpecFromArt(Artiste artiste) {
        artiste.ajouterSpectacle(this);
    }

    // ajouter une représentation
    protected void addRepresentation(Representation representation) {
        this.representations.add(representation);
    }

    public void ajouterRepresentation(Representation representation) {
    	if (representations.contains(representation)) {
            System.out.println("Représentation déjà présente dans la liste !");
        } else {
            addRepresentation(representation);
        }
    }

    // supprimer une représentation
    protected void removeRepresentation(Representation representation) {
        this.representations.remove(representation);
    }

    public void supprimerRepresentation(Representation representation) {
        if (!representations.contains(representation)) {
            System.out.println("Représentation non présente dans la liste !");
        } else if (representations.size() <= 1) {
            System.out.println("Il ne reste qu'une représentation dans la liste!");
        } else {
            removeRepresentation(representation);
        }
    }

    // ajouter artiste
    public void ajouterArtiste(Artiste artiste) {
        if (artiste.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (artistes.contains(artiste)) {
            System.out.println("Artiste déjà présent dans la liste !");
        } else {
            artistes.add(artiste);
        }
    }

    // supprimer artiste
    public void supprimerArtiste(Artiste artiste) {
        if (artiste.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (!artistes.contains(artiste)) {
            System.out.println("Artiste non présent dans la liste !");
        } else if (nbArtiste() <= 1) {
            System.out.println("Il ne reste qu'un artiste dans la liste!");
        } else {
            artistes.remove(artiste);
        }
    }

    // toString
    public String toString() {
        return "Spectacle [nom=" + nom + ", duree=" + duree + ", nombreActes=" + nombreActes + ", genre=" + genre + ", representations=" + representations + ", ListeZone=" + ListeZone + ", artistes=" + artistes + "]";
    }

    // affiche
    public void affiche() {
        System.out.println(this.toString());
    }

    /* equals
    public boolean equals(Spectacle s) {
        return this.nom.equals(s.nom) && this.duree == s.duree && this.nombreActes == s.nombreActes && this.genre.equals(s.genre) && this.representations.equals(s.representations) && this.ListeZone.equals(s.ListeZone) && this.artistes.equals(s.artistes);
    }
    */

    // ajouter Representation
    public void modifRepresentation(Representation representation) {
        if (representation == null) {
            System.out.println("Entrée nulle !");
        } else {
            addRepresentation(representation);
        }
    }

    // supprimer Zone 
    public void supprimerZone(Zone zone) {
    	if (!ListeZone.contains(zone)) {
            System.out.println("Zone non présente dans la liste !");
        } else {
            ListeZone.remove(zone);
        }
    }

    // ajouter Zone
    public void ajouterZone(Zone zone) {
    	if (ListeZone.contains(zone)) {
            System.out.println("Zone déjà présente dans la liste !");
        } else {
            ListeZone.add(zone);
        }
    }


}
