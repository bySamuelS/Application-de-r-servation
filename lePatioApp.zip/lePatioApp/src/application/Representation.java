package application;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Representation {
    private LocalDate jour;
    private String heure;
    private Boolean annulee;
    private Spectacle spectacle;
    private List<Reservation> reservations;

    // Constructeur
    public Representation(LocalDate jour, String heure, Boolean annulee, Spectacle spectacle) {
        this.jour = jour;
        this.heure = heure;
        this.annulee = annulee;
        this.spectacle = spectacle;
        this.reservations = new ArrayList<Reservation>();
    }

    // Getters
    public LocalDate getJour() {
        return jour;
    }
    public String getHeure() {
        return heure;
    }
    public Boolean getAnnulee() {
        return annulee;
    }
    public Spectacle getSpectacle() {
        return spectacle;
    }
    
    // Setters
    public void setJour(LocalDate jour) {
        this.jour = jour;
    }
    public void setHeure(String heure) {
        this.heure = heure;
    }
    public void setAnnulee(Boolean annulee) {
        this.annulee = annulee;
    }
    public void setSpectacle(Spectacle spectacle) {
        this.spectacle = spectacle;
    }    
    // toString
    public String toString() {
        return "Jour: " + jour + ", Heure: " + heure + ", Annulée: " + annulee;
    }
    // equals
    public boolean equals(Representation r) {
        return this.jour.equals(r.getJour()) && this.heure.equals(r.getHeure()) && this.annulee.equals(r.getAnnulee());
    }
    
    /*
    public boolean memeJour(Representation r) {
    	return this.jour.equals(r.getJour()) && !this.heure.equals(r.getHeure());
    }
    */

    // modification spectacle
    public void modifSpectacle(Spectacle spectacle) {
        if (this.spectacle != null) {
            this.spectacle = null;
        }
        else if (spectacle == null) {
            System.out.println("Entrée nulle !");
        }
        else {
            setSpectacle(spectacle);
        }

    }

    // ajouter reservation
    private void addReservation(Reservation reservation) {
        this.reservations.add(reservation);
    }

    public void modifReservation(Reservation reservation) {
        if (this.reservations.size() == 0) {
            System.out.println("Aucune réservation !");
        }
        else if (reservation == null) {
            System.out.println("Entrée nulle !");
        }
        else {
            this.reservations.clear();
            addReservation(reservation);
        }
    }

    // supprimer reservation
    private void removeReservation(Reservation reservation) {
        this.reservations.remove(reservation);
    }

    public void supprimerReservation(Reservation reservation) {
        if (this.reservations.size() == 0) {
            System.out.println("Aucune réservation !");
        }
        else if (reservation == null) {
            System.out.println("Entrée nulle !");
        }
        else if (!this.reservations.contains(reservation)) {
            System.out.println("Réservation non présente !");
        }
        else {
            removeReservation(reservation);
        }
    }
}