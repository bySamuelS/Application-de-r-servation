package application;

import java.util.Objects;

public class Billet {
    private String numero;
    protected Reservation reservation;

    public Billet(String numero, Reservation reservation) {
        this.numero = numero;
        this.reservation = reservation;
    }

    public String getNumero() {
        return numero;
    }
	    @Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Billet other = (Billet) obj;
		return Objects.equals(numero, other.numero);
	}

    protected void modifReservation(Reservation reservation) {
        this.reservation = reservation;
    }

    public void modifierReservation (Reservation reservation) {
        if (reservation.equals(null)) {
            System.out.println("Entrée nulle !");
        } else {
            modifReservation(reservation);
        }
    }
}


