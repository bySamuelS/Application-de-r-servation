package application;

import java.util.Objects;
import java.util.ArrayList;

public class Fauteuil {
    private String numero;
    private String rangee;
    protected ArrayList<Billet> listBillets = new ArrayList<Billet>();
    protected Zone zone;

    public Fauteuil(String numero, String rangee, Zone zone) {
        this.numero = numero;
        this.rangee = rangee;
        this.zone = zone;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getRangee() {
        return rangee;
    }

    public void setRangee(String rangee) {
        this.rangee = rangee;
    }


    @Override
    public String toString() {
        return "Fauteil{" +
                "numero='" + numero + '\'' +
                ", rangee='" + rangee + '\'' +
                '}';
    }

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fauteuil other = (Fauteuil) obj;
		return Objects.equals(numero, other.numero) && Objects.equals(rangee, other.rangee);
	}

    protected void addBillet(Billet billet) {
        listBillets.add(billet);
    }

    protected void removeBillet(Billet billet) {
        listBillets.remove(billet);
    }

    public void ajouterBillet(Billet billet) {
        if (billet.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (listBillets.contains(billet)) {
            System.out.println("Billet déjà présent dans la liste !");
        } else {
            addBillet(billet);
        }
    }

    public void supprimerBillet(Billet billet) {
        if (billet.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (!listBillets.contains(billet)) {
            System.out.println("Billet non présent dans la liste !");
        } else {
            removeBillet(billet);
        }
    }

    public void afficherBillets() {
        for (Billet billet : listBillets) {
            System.out.println(billet.toString());
        }
    }

    public void afficherBillet(Billet billet) {
        if (billet.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (!listBillets.contains(billet)) {
            System.out.println("Billet non présent dans la liste !");
        } else {
            System.out.println(billet.toString());
        }
    }   

    public void afficherFauteuil() {
        System.out.println(this.toString());
        afficherBillets();
    }

    public void afficherFauteuil(Billet billet) {
        if (billet.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (!listBillets.contains(billet)) {
            System.out.println("Billet non présent dans la liste !");
        } else {
            System.out.println(this.toString());
            System.out.println(billet.toString());
        }
    }
    
    public ArrayList<Billet> getListBillets() {
        return listBillets;
    }
    
    public void setListBillets(ArrayList<Billet> listBillets) { 
        this.listBillets = listBillets;
    }

    public Zone getZone() {
        return zone;
    }
    
    public void setZone(Zone zone) {
        this.zone = zone;
    }

    // modifier zone
    public void modifierZone(Zone zone) {
        if (zone.equals(null)) {
            System.out.println("Entrée nulle !");
        } else {
            this.zone = zone;
        }
    }

    // modifier rangee
    public void modifierRangee(String rangee) {
        if (rangee.equals(null)) {
            System.out.println("Entrée nulle !");
        } else {
            this.rangee = rangee;
        }
    }
}