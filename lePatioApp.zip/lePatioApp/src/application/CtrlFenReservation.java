package application;

import javafx.beans.binding.Bindings;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javafx.beans.binding.BooleanBinding;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.application.Application;


public class CtrlFenReservation {
	
    int min = 1000000; // Minimum value
    int max = 9999999; // Maximum value
	
	private DatabaseSpectacle listeSpectacles = new DatabaseSpectacle();
	private String nomSpecSelec;
	private int numCli;
	private Client clientRes;
	private String numRes;
	private boolean fossechoisie = false;
	
	@FXML private Button bnAnnuler;
    @FXML private Button bnValider;
    @FXML private ComboBox<String> selectSpectacle;
    @FXML private ComboBox<String> selectZone;
    @FXML private DatePicker dateRepresentation;
    @FXML private RadioButton radioRep1;
    @FXML private RadioButton radioRep2;
    @FXML private TextField txtPlacement;
    @FXML private TextField tAdulte;
    @FXML private TextField tSenior;
    @FXML private TextField tAbonne;
    @FXML private TextField tJeune;
    @FXML private TextField txtNumero;
    
    @FXML void clicAnnuler(ActionEvent event) throws Exception {
    	txtPlacement.setText(null);
		txtNumero.setText(null);
		selectSpectacle.setValue(null);
		selectZone.setValue(null);
		dateRepresentation.setValue(null);
		tAdulte.setText("0");
        tJeune.setText("0");
        tSenior.setText("0");
        tAbonne.setText("0");
    	Main.fermerReservation();
    }

    @FXML void clicValider(ActionEvent event) throws Exception {   
    	
    	numCli = Integer.parseInt(txtNumero.getText());
    	
    	clientRes = CtrlFenAccueil.DBClient.trouverClientParNumero(numCli);
    	
    	
    	
    	if (clientRes != null && !(clientRes.estAbonne == false && isTarifGreaterThanZero(tAbonne))) {
    		Random rand = new Random();
        	int randomNumber = rand.nextInt(max - min + 1) + min;
        	numRes = String.valueOf(randomNumber);
        	Reservation reservation = new Reservation(
        			numRes, 
        			dateRepresentation.getValue(), 
        			dateRepresentation.getValue(), 
        			clientRes);
        		clientRes.ajouterReservation(reservation);
        		txtPlacement.setText(null);
        		txtNumero.setText(null);
        		selectSpectacle.setValue(null);
        		selectZone.setValue(null);
        		dateRepresentation.setValue(null);
        		tAdulte.setText("0");
                tJeune.setText("0");
                tSenior.setText("0");
                tAbonne.setText("0");
        		Main.fermerReservation();
    	}else if(clientRes == null){
            System.out.println("Client non trouvé pour le numéro : " + numCli);
            afficherAlerteClientNonTrouve(numCli);
            
        }
    	else if(clientRes.estAbonne == false && isTarifGreaterThanZero(tAbonne)) {
    		Alert alerte2 = new Alert(Alert.AlertType.WARNING);
        	
        	alerte2.setTitle("Erreur abonnement");
            alerte2.setHeaderText("Le client doit être abonné pour sélectionner un tarif abonné.");
            
            alerte2.showAndWait();
        } 
    	
    	
    	
    }
    
    private void afficherAlerteClientNonTrouve(int numeroClient) throws Exception {
        Alert alerte = new Alert(Alert.AlertType.CONFIRMATION);
        alerte.setTitle("Client non trouvé");
        alerte.setHeaderText("Le client avec le numéro " + numeroClient + " n'a pas été trouvé.");
        alerte.setContentText("Voulez-vous créer un nouveau client ?");

        ButtonType btnCreerClient = new ButtonType("Créer client");
        ButtonType btnAnnuler = new ButtonType("Annuler");

        alerte.getButtonTypes().setAll(btnCreerClient, btnAnnuler);

        alerte.showAndWait().ifPresent(buttonType -> {
            if (buttonType == btnCreerClient) {
                // Ajoutez ici la logique pour créer un nouveau client
                System.out.println("Création d'un nouveau client...");
                // Exemple : Ouverture d'une nouvelle fenêtre pour créer un client
                try {
					Main.ouvrirFenClient();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            } else {
                System.out.println("Action annulée.");
            }
        });
    }
    
    private ObservableList<String> nomsZone;
    
    @FXML 
    private void spectacleSelected() {
        if (selectSpectacle.getValue() != null && !selectSpectacle.getValue().isEmpty()) {
        	
        	Spectacle selectedSpectacle = spectacleMap.get(selectSpectacle.getValue());
        	nomsZone = FXCollections.observableArrayList();
        	
        	// Initialiser la carte
            for (Zone zone : selectedSpectacle.ListeZone) {
                nomsZone.add(zone.getNom());
            }
            
            dateRepresentation.setValue(null); // Réinitialiser la sélection de date
            dateRepresentation.setDisable(false);
            selectZone.setItems(nomsZone);
            selectZone.setDisable(false);

            nomSpecSelec = selectSpectacle.getValue();
            
            // Reconfigurer le DatePicker pour forcer la mise à jour
            configureDatePicker();
        } else {
            dateRepresentation.setDisable(true);
            radioRep1.setDisable(true);
            radioRep2.setDisable(true);
            selectZone.setDisable(true);
            txtPlacement.setDisable(true);
        }
    }
    
    @FXML private void zoneSelected() {
    	if (selectZone.getValue() != null && selectZone.getValue() != "Fosse") {
            txtPlacement.setDisable(false);
    	}
    	else {
    		txtPlacement.setText(null);
    		fossechoisie = true;
            txtPlacement.setDisable(true);
    	}
    }
    private Map<String, Spectacle> spectacleMap = new HashMap<>();
    
    
    public void initialize() {
    	
    	// Initialiser le DatePicker pour la première fois
        configureDatePicker();
        
    	// Initialiser la carte
        for (Spectacle spectacle : listeSpectacles.getSpectacles()) {
            spectacleMap.put(spectacle.getNom(), spectacle);
        }
        
        tAdulte.setText("0");
        tJeune.setText("0");
        tSenior.setText("0");
        tAbonne.setText("0");
        
        // Ajouter les listeners pour les changements de valeur des textfields de tarif
        tAdulte.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        tJeune.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        tSenior.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        tAbonne.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());

        // Ajouter les listeners pour les changements de sélection des combobox et radiobuttons
        selectSpectacle.valueProperty().addListener((observable, oldValue, newValue) -> {
            spectacleSelected();
            updateValiderButton();
        });
        selectZone.valueProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        txtPlacement.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        radioRep1.selectedProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        radioRep2.selectedProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        txtNumero.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
        
        
        //Initialiser le comboBox
    	selectSpectacle.setItems(listeSpectacles.getNomSpectacles());
    	
    	// Ajouter un listener pour le changement de date
        dateRepresentation.valueProperty().addListener((observable, oldValue, newValue) -> updateRadioButtons(newValue));
    }
    
    private void configureDatePicker() {
        dateRepresentation.setDayCellFactory(new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);

                        Spectacle selectedSpectacle = spectacleMap.get(selectSpectacle.getValue());
                        if (selectedSpectacle != null) { 
                            // Initialiser la carte des dates autorisées
                            Map<LocalDate, Representation> repMap = new HashMap<>(); 
                            for (Representation rep : selectedSpectacle.getRepresentations()) {
                                repMap.put(rep.getJour(), rep);
                            }

                            if (item != null && !repMap.containsKey(item)) {
                                setDisable(true);
                                setStyle("-fx-background-color: #ffc0cb;"); // Couleur pour les dates désactivées
                            }
                        } else {
                            setDisable(false); // Réinitialiser les cellules non associées
                            setStyle(null);
                        }
                    }
                };
            }
        });
    }
    
    private void updateRadioButtons(LocalDate selectedDate) { 
        Spectacle selectedSpectacle = spectacleMap.get(selectSpectacle.getValue());
        if (selectedSpectacle != null && selectedDate != null) {
            long count = selectedSpectacle.getRepresentations().stream()
                    .filter(rep -> rep.getJour().equals(selectedDate))
                    .count();

            if (count > 1) {
                radioRep1.setDisable(false);
                radioRep1.setSelected(true);
                radioRep2.setDisable(false);
            } else if (count == 1) {
                radioRep1.setDisable(false);
                radioRep1.setSelected(true);
                radioRep2.setDisable(true);
            } else {
                radioRep1.setDisable(true);
                radioRep1.setSelected(false);
                radioRep2.setDisable(true);
                radioRep2.setSelected(false);
            }
        } else {
        	radioRep1.setSelected(false);
            radioRep1.setDisable(true);
            radioRep2.setDisable(true);
            radioRep2.setSelected(false);
        }
    }
    
 // Suppose tarifTextField est votre TextField pour le tarif
    private boolean isTarifGreaterThanZero(TextField tarifTextField) {
        // Récupérer la valeur du TextField et la convertir en double
        try {
            double tarif = Double.parseDouble(tarifTextField.getText());
            return tarif > 0.0;
        } catch (NumberFormatException e) {
            // En cas d'erreur de conversion ou si le champ est vide
            return false;
        }
    }
    
    private boolean checkIfValid() {
        boolean isSpectacleSelected = selectSpectacle.getValue() != null && !selectSpectacle.getValue().isEmpty();
        boolean isDateSelected = dateRepresentation.getValue() != null;
        boolean isRepresentationSelected = radioRep1.isSelected() || radioRep2.isSelected();
        boolean isZoneSelected = selectZone.getValue() != null && !selectZone.getValue().isEmpty();
        boolean isPlaceSelected = txtPlacement.getText() != null && !txtPlacement.getText().isEmpty() || fossechoisie == true;
        boolean isClientSelected = txtNumero.getText() != null && !txtNumero.getText().isEmpty();

        boolean isAnyTarifGreaterThanZero = isTarifGreaterThanZero(tAdulte) || isTarifGreaterThanZero(tJeune)
                || isTarifGreaterThanZero(tSenior) || isTarifGreaterThanZero(tAbonne);

        return isSpectacleSelected && isDateSelected && isRepresentationSelected && isZoneSelected && isPlaceSelected && isAnyTarifGreaterThanZero && isClientSelected;
    }
    
 // Fonction pour mettre à jour l'état du bouton Valider
    private void updateValiderButton() {
    	boolean isValid = checkIfValid();
        bnValider.setDisable(!isValid);
    }
}