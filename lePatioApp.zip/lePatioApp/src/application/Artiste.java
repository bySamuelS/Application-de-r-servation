package application;

import java.util.ArrayList;
import java.util.List;

public class Artiste {
    private String nom;

    // Associations
    private List<Spectacle> spectacles;

    // Constructor
    public Artiste(String nom) {
        this.nom = nom;
        this.spectacles = new ArrayList<Spectacle>();
    }

    // Getters and Setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public List<Spectacle> getSpectacles() {
        return spectacles;
    }

    protected void addSpectacle(Spectacle spectacle) {
        this.spectacles.add(spectacle);
    }

    protected void removeSpectacle(Spectacle spectacle) {
        this.spectacles.remove(spectacle);
    }

    protected int nbSpectacles() {
        return this.spectacles.size();
    }

    // ajouter spectacle
    public void ajouterSpectacle(Spectacle spectacle) {
        if (spectacle.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (spectacles.contains(spectacle)) {
            System.out.println("Spectacle déjà présent dans la liste !");
        } else {
            spectacles.add(spectacle);
        }
    }

    // supprimer spectacle
    public void supprimerSpectacle(Spectacle spectacle) {
        if (spectacle.equals(null)) {
            System.out.println("Entrée nulle !");
        }
    }
}
