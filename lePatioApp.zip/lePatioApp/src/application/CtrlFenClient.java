package application;

import javafx.beans.binding.Bindings;
import java.time.LocalDate;
import java.util.Random;

import javax.swing.text.StyledEditorKit.ForegroundAction;

import javafx.beans.binding.BooleanBinding;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.application.Application;


public class CtrlFenClient {
	
	@FXML private Button bnAnnuler;
    @FXML private Button bnValider;
    @FXML private TextField txtNom;
    @FXML private TextField txtPrenom;
    @FXML private TextField txtAdresse1;
    @FXML private TextField txtAdresse2;
    @FXML private TextField txtTel;
    @FXML private TextField txtMail;
    @FXML private TextField txtNumero;

    @FXML void clicAnnuler(ActionEvent event) throws Exception {
    	txtNom.setText(null);
    	txtPrenom.setText(null);
    	txtAdresse1.setText(null);
    	txtAdresse2.setText(null);
    	txtTel.setText(null);
    	txtMail.setText(null);
    	Main.fermerClient();
    }

    @FXML void clicValider(ActionEvent event) throws Exception {
    	Client client = new Client(
    			txtNom.getText(), 
    			txtPrenom.getText(), 
    			txtAdresse1.getText()+" "+txtAdresse2.getText(), 
    			txtTel.getText(), 
    			txtMail.getText());
    	CtrlFenAccueil.DBClient.add(client);
    	txtNom.setText(null);
    	txtPrenom.setText(null);
    	txtAdresse1.setText(null);
    	txtAdresse2.setText(null);
    	txtTel.setText(null);
    	txtMail.setText(null);
    	Main.fermerClient();
    	
    	System.out.println(client.getNumero());
    }
    
    public void initialize() {
    	txtNom.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
    	txtPrenom.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
    	txtAdresse1.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
    	txtTel.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
    	txtMail.textProperty().addListener((observable, oldValue, newValue) -> updateValiderButton());
    }
    
    private boolean checkIfValid() {
        boolean isNomSelected = txtNom.getText() != null && !txtNom.getText().isEmpty();
        boolean isPrenomSelected = txtPrenom.getText() != null && !txtPrenom.getText().isEmpty();
        boolean isAdresse1Selected = txtAdresse1.getText() != null && !txtAdresse1.getText().isEmpty();
        boolean isTelSelected = txtTel.getText() != null && !txtTel.getText().isEmpty() && txtTel.getText().length() >= 10;
        boolean isMailSelected = txtMail.getText() != null && !txtMail.getText().isEmpty() && txtMail.getText().contains("@") && txtMail.getText().contains(".");

        return isNomSelected && isPrenomSelected && isAdresse1Selected && isTelSelected && isMailSelected;
    }
    
 // Fonction pour mettre à jour l'état du bouton Valider
    private void updateValiderButton() {
    	boolean isValid = checkIfValid();
        bnValider.setDisable(!isValid);
    }
    
    
}