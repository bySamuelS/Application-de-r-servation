package application;
    public class Tarif {
        private double pleinTarif;
        private Spectacle spectacle;
    
        // Constructeur
        public Tarif(double pleinTarif, Spectacle spectacle) {
            this.pleinTarif = pleinTarif;
            this.spectacle = spectacle;
        }
    
        // Getters et Setters
        public double getPleinTarif() {
            return pleinTarif;
        }
    
        public void setPleinTarif(double pleinTarif) {
            this.pleinTarif = pleinTarif;
        }
    
        public Spectacle getSpectacle() {
            return spectacle;
        }
    
        public void setSpectacle(Spectacle spectacle) {
            this.spectacle = spectacle;
        }
    
        @Override
        public String toString() {
            return "Tarif{" +
                    "pleinTarif=" + pleinTarif +
                    ", spectacle=" + spectacle.getNom() +
                    '}';
        }
    }
