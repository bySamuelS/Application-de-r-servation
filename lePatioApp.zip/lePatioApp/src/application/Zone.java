package application;

import java.util.List;
import java.util.ArrayList;

public class Zone {
    private String nom;
    private List<Spectacle> ListeSpectacle;

    //Constructeur
    public Zone(String nom, Spectacle initSpectacle) {
        this.nom = nom;
        this.ListeSpectacle = new ArrayList<Spectacle>();
        this.ListeSpectacle.add(initSpectacle);
    }

    public Zone(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    // Modification de spectacle
    public List<Spectacle> getListeSpectacle() {
        return ListeSpectacle;
    }
    public void setListeSpectacle(List<Spectacle> listeSpectacle) {
        this.ListeSpectacle = listeSpectacle;
    }
    private void addSpectacle(Spectacle spectacle) {
        this.ListeSpectacle.add(spectacle);
    }
    private void removeSpectacle(Spectacle spectacle) {
        this.ListeSpectacle.remove(spectacle);
    }
    public void ajouterSpectacle(Spectacle spectacle) {
        if (spectacle.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (ListeSpectacle.contains(spectacle)) {
            System.out.println("Spectacle déjà présent dans la liste !");
        } else {
            addSpectacle(spectacle);
            spectacle.addZone(this);
        }
    }
    public void supprimerSpectacle(Spectacle spectacle) {
        if (spectacle.equals(null)) {
            System.out.println("Entrée nulle !");
        } else if (!ListeSpectacle.contains(spectacle)) {
            System.out.println("Spectacle non présent dans la liste !");
        } else {
            removeSpectacle (spectacle);
        }
    }
    public void affiche() {
        System.out.println(this.toString());
    }
    public String toString() {
        return "Nom de la zone : " + this.nom + "\nListe des spectacles : " + this.ListeSpectacle.toString();
    }
    public boolean equals(Zone z) {
        return this.nom.equals(z.getNom());
    }

}
